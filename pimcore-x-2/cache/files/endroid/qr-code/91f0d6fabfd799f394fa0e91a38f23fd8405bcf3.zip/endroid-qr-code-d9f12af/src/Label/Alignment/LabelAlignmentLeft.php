<?php

declare(strict_types=1);

namespace Endroid\QrCode\Label\Alignment;

final class LabelAlignmentLeft implements LabelAlignmentInterface
{
}
