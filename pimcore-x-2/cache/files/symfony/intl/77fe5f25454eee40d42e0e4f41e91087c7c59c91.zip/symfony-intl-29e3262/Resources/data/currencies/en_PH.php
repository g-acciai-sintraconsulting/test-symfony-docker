<?php

return [
    'Names' => [
        'PHP' => [
            0 => '₱',
            1 => 'Philippine Piso',
        ],
    ],
];
