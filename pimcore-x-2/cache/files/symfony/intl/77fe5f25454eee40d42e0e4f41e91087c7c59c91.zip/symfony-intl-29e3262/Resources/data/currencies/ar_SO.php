<?php

return [
    'Names' => [
        'SOS' => [
            0 => 'S',
            1 => 'شلن صومالي',
        ],
    ],
];
