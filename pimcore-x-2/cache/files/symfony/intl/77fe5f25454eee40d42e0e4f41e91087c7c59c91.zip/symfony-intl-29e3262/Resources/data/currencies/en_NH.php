<?php

return [
    'Names' => [
        'VUV' => [
            0 => 'VT',
            1 => 'Vanuatu Vatu',
        ],
    ],
];
