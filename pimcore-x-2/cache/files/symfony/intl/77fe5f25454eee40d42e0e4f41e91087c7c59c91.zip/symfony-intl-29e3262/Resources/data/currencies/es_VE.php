<?php

return [
    'Names' => [
        'VEF' => [
            0 => 'Bs.',
            1 => 'bolívar venezolano (2008–2018)',
        ],
        'VES' => [
            0 => 'Bs.S',
            1 => 'bolívar soberano',
        ],
    ],
];
