<?php

return [
    'Names' => [
        'HNL' => [
            0 => 'L',
            1 => 'lempira hondureño',
        ],
    ],
];
